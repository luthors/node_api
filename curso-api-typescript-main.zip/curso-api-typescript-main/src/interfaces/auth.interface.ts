export interface Auth {
  email: string;
  password: string;
}
