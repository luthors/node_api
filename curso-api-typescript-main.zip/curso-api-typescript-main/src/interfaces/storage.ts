export interface Storage {
  fileName: string;
  path: string;
  idUser: string;
}
